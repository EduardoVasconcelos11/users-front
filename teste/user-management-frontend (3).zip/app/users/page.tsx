import { UsersView } from "@/views/users"

export default function UsersPage() {
  return <UsersView />
}
