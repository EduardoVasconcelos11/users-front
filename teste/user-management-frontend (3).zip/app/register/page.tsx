import { RegisterView } from "@/views/register"

export default function RegisterPage() {
  return <RegisterView />
}
