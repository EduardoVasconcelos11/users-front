import { ProfileView } from "@/views/profile"

export default function ProfilePage() {
  return <ProfileView />
}
